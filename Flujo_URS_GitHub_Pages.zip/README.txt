PUBLICAR EN GITHUB PAGES

1. Crea un repositorio nuevo en GitHub, por ejemplo: flujo-urs
2. Sube el archivo index.html a la raíz del repositorio.
3. Ve a Settings > Pages.
4. En 'Build and deployment', selecciona:
   Source: Deploy from a branch
   Branch: main
   Folder: /(root)
5. Guarda.
6. En unos minutos GitHub mostrará una URL parecida a:
   https://TU-USUARIO.github.io/flujo-urs/

El archivo index.html ya está listo para publicarse.
